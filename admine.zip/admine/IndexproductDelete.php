<?php 
session_start();
if(isset($_SESSION["ad_session"]))
{

include("header.php");
		include("conn.php");
$delsel=mysqli_query($con,"select Indexproduct_image from indexproduct where IndexProduct_id=".$_REQUEST["id"]);
if($r=mysqli_fetch_row($delsel))
{
	unlink("../".$r[0]);
	mysqli_query($con,("delete from indexproduct where IndexProduct_id=".$_REQUEST['id']));
}

echo "<script>window.location='IndexproductView.php';</script>";
include("footer.php"); 
}	
	else
		echo "<script>window.location='Login.php';</script>";

?>
