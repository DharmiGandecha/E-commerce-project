<html>
	<head>
		<style>
			table{
				background-color:#7f4e52;
				width:30%;
				height:70%;
				
			}
			#u{
				color:black;
				background-color:#7f4e52;
				width:120px;
			}
			
			
		</style>
</head>
</html>
<?php 
session_start();
if(isset($_SESSION["ad_session"]))
{
include("header.php"); ?>
<br />
<br />

<section class="w3ls-bnrbtm py-5" id="about">
		<div class="container py-xl-5 py-lg-3">
			<div class="row pb-5">
				<div class="col-lg-12">
<center>
		<form name="form1" method="post" enctype="multipart/form-data">
		<h1>Add Category Data</h1>
		<table border="3" style="background-color:lightblue">
			<tr>
				<td>Category_name  </td>
				<td><input type="text" name="name" required/></td>
			</tr>
			
			
			<tr align="center">
				<td colspan="2">
				<a href="CategoryView.php"><input id="u" type="button" name="sub" value="Back" /></a>	
				<input  id="u" type="submit" name="sub" value="submit" /></td>
			</tr>
		</table>
		
		</form>
	</center>
	</div>
	</div>
	</div>
	</section>

<?php
	include("footer.php");
	include("conn.php");
	
	if(isset($_POST["sub"]))
	{
		
		$nm=$_POST["name"];
		//$path="upload/".$_FILES["img"]["name"];
		//move_uploaded_file($_FILES["img"]["tmp_name"],"../".$path);
		mysqli_query($con,"insert into category values(null,'$nm')");
		
		echo "<script>window.location='CategoryView.php';</script>";
	}
}	
	else
		echo "<script>window.location='login.php';</script>";
?>