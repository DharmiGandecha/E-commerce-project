<html>
	<head>
		<style>
			table{
				background-color:#D6EEEE;
				
			}
			#u{
				color:black;
				background-color:#f7d1cd;
				width:120px;
			}
		</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION["ad_session"]))
{
	
	include("header.php");
	include "conn.php";
	$selpro=mysqli_query($con,"select * from indexproduct where IndexProduct_id=".$_REQUEST["id"]);
	$r_pro=mysqli_fetch_row($selpro);
?>
<center>
		<form name="form1" method="post" action="IndexproductEdit.php" enctype="multipart/form-data">
		<h1>Update IndexProduct Data</h1>
		<br />
		<table border="3">
	
			<tr>
				<td>cart_id<?php echo $r_pro[1]; ?></td>
				<td>
					<select name="cat_id">
					<?php
						$selcat=mysqli_query($con,"select * from category");
					while($cat=mysqli_fetch_array($selcat))
					{
						?>
							<option <?php if($r_pro[1]==$cat[0])
							echo "selected"; ?> value="<?php echo $cat[0]; ?>"><?php echo $cat[1]; ?></option>
						<?php
					}
					?>
					</select>
				</td>
			</tr>

			<tr>
				<td>product_name  </td>
				<td><input type="text" name="pro_name" value="<?php echo $r_pro[2]; ?>" /></td>
			</tr>
			
			<tr>
				<td>product_image</td>
				<td>
				<input type="file" name="pro_img" />
				<input type="hidden" name="old_img" value="<?php echo $r_pro[3]; ?>" />
				<input type="hidden" name="proid" value="<?php echo $r_pro[0]; ?>" />	
				<img src="../<?php echo $r_pro[3]; ?>" height="220px" width="220px" />
				</td>
			</tr>
			
			<tr align="center">
				<td colspan="2"> 
				<a href="IndexproductView.php"><input id="u" type="button" name="sub" value="Back" /></a>	
				<input id="u" type="submit" name="pro_upd" value="submit" /></td>
			</tr>
		</table>
		
		</form>
</center>
<br />
<br />
<?php
	include("footer.php");
	}	
	else
		echo "<script>window.location='Login.php';</script>";

?>