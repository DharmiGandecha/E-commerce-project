<?php
session_start();
include "conn.php";
if(isset($_REQUEST["LOGIN"]))
{
	$getuser=mysqli_query($con,"select * from adminlogin where Email_id='".$_REQUEST["email"]."' AND password='".$_REQUEST["password"]."'");
	$res=mysqli_fetch_row($getuser);
	$nores=mysqli_num_rows($getuser);
	if($nores>0)
	{
		$_SESSION["ad_session"]=$res[1];
		echo "<script>window.location='index.php';</script>";
	}	
	//$execute_query=mysqli_query($con,$getuser);
	//if($con->query($getuser)===TRUE)
	//{
	//	$_SESSION["ad_session"]=$res[1];
	//	echo "<script>window.location='index.php';</script>";
		
	//}
	else
		echo "<script>window.location='login.php';</script>";
		echo "Hello!";
	}	
else
	echo "<script>window.location='login.php';</script>";
	echo "Hello!";
?>