<html>
	<head>
		<style>
			table{
				background-color:#afdcec;
				width:50%;
				height:50%;
				
			}
			#u{
				color:black;
				background-color:#afdcec;
				width:120px;
			}
			
			
		</style>
</head>
</html>
<?php 
session_start();
if(isset($_SESSION["ad_session"]))
{
include "header.php"; 
include("conn.php");
$selcat=mysqli_query($con,"select * from category")
?>

<center>
		<form name="form1" method="post" enctype="multipart/form-data">
		<h1>Add your products here:</h1><br>
		<table border="3">
	
			<tr>
				<td>cart_id</td>
				<td>
					<select name="cat_id">
					<?php
					while($cat=mysqli_fetch_array($selcat))
					{
						?>
							<option value="<?php echo $cat[0]; ?>"><?php echo $cat[1]; ?></option>
						<?php
					}
					?>
					</select>
				</td>
			</tr>

			<tr>
				<td>product_name  </td>
				<td><input type="text" name="pro_name" required/></td>
			</tr>
			
			<tr>
				<td>product_detail</td>
				<td><input type="text" name="pro_detail" required/></td>
			</tr>
			
			<tr>
				<td>product_price</td>
				<td><input type="text" name="pro_price" required/></td>
			</tr>

			<tr>
				<td>product_image</td>
				<td><input type="file" name="pro_img" required/></td>
			</tr>
			
			<tr align="center">
			<td colspan="2"> 	
				<a href="ProductView.php"><input id="u" type="button" name="sub" value="Back" /></a>
				<input   id="u" type="submit" name="sub" value="submit" /></td>
			</tr>
		</table>
		
		</form>
</center>
	</body>
</html>
<?php
	include "footer.php";
	
	
	if(isset($_POST["sub"]))
	{
		$cid=$_POST["cat_id"];
		$nm=$_POST["pro_name"];
		$dt=$_POST["pro_detail"];
		$pr=$_POST["pro_price"];
		$path="upload/".$_FILES["pro_img"]["name"];
		move_uploaded_file($_FILES["pro_img"]["tmp_name"],"../".$path);
		mysqli_query($con,"insert into product values(null,'$cid','$nm','$dt','$pr','$path')");
		
		echo "<script>window.location='ProductView.php';</script>";
	}
}	
	else
		echo "<script>window.location='Login.php';</script>";

?>