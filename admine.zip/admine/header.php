<head>
    <meta charset="utf-8">
    <title>Closet Secrets</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style1.css" rel="stylesheet">
</head>

<!-- Topbar Start -->
    <div class="container-fluid">
        
        <div class="row bg-secondary align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                <h1>Closet Secrets</h1> 
                <!--<h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">B</span>irthday</h1>-->
                </a>
            </div>
            <div style="padding-right:5px;">
                <nav class="navbar navbar-expand-lg navbar-light py-3 py-lg-0 px-0">
                   
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse" >
                        <div class="navbar-nav mr-auto py-0" >
                            <a href="index.php" class="nav-item nav-link active">Home</a>
                            <a href="CategoryView.php" class="nav-item nav-link">Catagory</a>
                           
                            <a href="ProductView.php" class="nav-link" >Products</a>
                            <a href="FeedbackView.php" class="nav-item nav-link">Message</a>
                            <a href="login.php" class="nav-item nav-link">Logout</a>
                        </div>
                        
                    </div>
                </nav>
            </div>
           <!--<div class="col-lg-3 col-6 text-right" >
                <a href="" class="btn border" >
                    
                    <span class="badge">Profile</span>
                </a>
                
            </div>-->
        
        </div>
    </div>
    <!-- Topbar End -->