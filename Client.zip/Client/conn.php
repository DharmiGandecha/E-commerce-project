<?php
$servername="localhost";
$username="root";
$pass="";
$dbase="ClosetSecrets";

$con=new mysqli($servername,$username,$pass,$dbase);
	if($con->connect_error)
	{
		die ("connection done".$con->connection_aborted_error);
	}
?>