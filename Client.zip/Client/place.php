<!DOCTYPE>
<html>
    <head>
        <title>order placed successfully</title>
        <link href="css/style2.css" rel="stylesheet">
</head>
<body>
    <div class="place">
    <h1>Order placed successfully recieved!!</h1>
    <p>Thank you for your order</p>
    <p>We're thrilled that you've chosen to shop with us.we'll get your order ready and shipped out to you
as soon  as possible.</p>
</div>

</body>
</html>