
<?php include "conn.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Product page</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style1.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <?php
            include('header.php');
        ?>
    <!-- Topbar End -->



    <div class="container-fluid mb-5">
        <div class="row border-top px-xl-5">
          
            <div class="col-lg-9" style="margin-left: 150px;">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                   
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse" >
                        <div class="navbar-nav mr-auto py-0">
                            <a href="Index.php" class="nav-item nav-link active">Home</a>
                            
                            <a href="cart.php" class="nav-item nav-link">cart</a>
                            <div class="nav-item dropdown">
                                <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">Products</a>
                                <div class="dropdown-menu rounded-0 m-0">
                               
                               <?php
								$cat=mysqli_query($con,"select * from category");
								while($rcat=mysqli_fetch_array($cat))
								{
								?>
								<li><a class="dropdown-item" href="Product.php?cid=<?php echo $rcat[0]; ?>" class="drop-text"><?php echo $rcat[1]; ?></a></li>
								<?php
								}
								?>
                                      
                                </div>
                            </div>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <?php
         $pro=mysqli_query($con,"select * from product where cat_id=".$_REQUEST["cid"]);

		if(mysqli_num_rows($pro)>0)
		{
		?>
			<h3 class="title-w3ls text-center text-bl mb-5">Products</h3>
			<div class="row">
				<!-- blog grid -->
				<?php
				while($rpro=mysqli_fetch_array($pro))
				{
				?>
				<div class="col-lg-4 col-md-6 px-md-2">
					<div class="card">
						<div class="card-header p-0 position-relative">
							<a href="detail.php?id=<?php echo $rpro[0]; ?>">
								<img class="card-img-bottom" src="<?php echo $rpro[5]; ?>" alt="Card image cap">
							</a>
						</div>
						<div class="card-body">
                        <h5 class="blog-title card-title"><?php echo $rpro[2]; ?></h5>
						<h5 class="mb-1">Price : Rs.<?php echo $rpro[4]; ?></h5>
                            <div class="card-footer d-flex justify-content-between bg-light border">
                                     <a href="detail.php?id=<?php echo $rpro[0]; ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                                     <a href="detail.php?id=<?php echo $rpro[0]; ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                            </div>
						</div>
					</div>
				</div>
				<?php
				}
				?>
			</div>
			<?php
			}
			else
			{
			?>
			<h3 class="title-w3ls text-center text-bl mb-5">No Products Available</h3>
			<?php
			}
			?>
    <!-- Footer Start -->
    <?php
            include('footer.php');
        ?>

        
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>