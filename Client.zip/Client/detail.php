<?php include "conn.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>detail page</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style1.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
        <?php
            include('header.php');
        ?>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid">
        <div class="row border-top px-xl-5">
           
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="Index.php" class="nav-item nav-link active">Home</a>
                           
                            <a href="cart.php" class="nav-item nav-link">cart</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">products</a>
                                <div class="dropdown-menu rounded-0 m-0">
                                <?php
								$cat=mysqli_query($con,"select * from category");
								while($rcat=mysqli_fetch_array($cat))
								{
								?>
								<li><a class="dropdown-item" href="Product.php?cid=<?php echo $rcat[0]; ?>" class="drop-text"><?php echo $rcat[1]; ?></a></li>
								<?php
								}
								?>
                                </div>
                            </div>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                      
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Shopping Now</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="Index.php">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Detail</p>
            </div>
        </div>
    </div>
<?php
    $pro=mysqli_query($con,"select * from product where pro_id=".$_REQUEST["id"]);
	$r=mysqli_fetch_row($pro);
?>
    <!-- Page Header End -->


    <!-- Shop Detail Start -->
    <div class="container-fluid py-5">
        <div class="row px-xl-5">
            <div class="col-lg-5 pb-5">
                <div id="product-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner border">
                        <div class="carousel-item active">
                            <img class="w-100 h-100" src="<?php echo $r[5]; ?>" alt="Image">
                        </div>
                      
                </div>
            </div>
        </div>
            <div class="col-lg-7 pb-5">
                <h3 class="font-weight-semi-bold"><?php echo $r[2]; ?></h3>
               
                <h3 class="font-weight-semi-bold mb-4">Price : <?php echo $r[4]; ?></h3>
                <p class="mb-4">Description : <?php echo $r[3]; ?></p>
               
                <div class="d-flex align-items-center mb-4 pt-2">
                    <div class="input-group quantity mr-3" style="width: 130px;">
                        <div class="input-group-btn">
                            <button class="btn btn-primary btn-minus" >
                            <i class="fa fa-minus"></i>
                            </button>
                        </div>
                        <input type="text" class="form-control bg-secondary text-center" value="1">
                        <div class="input-group-btn">
                            <button class="btn btn-primary btn-plus">
                                <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    
                    
                </div>
                <a href="cart.php"><button class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i> Add To Cart</button></a>
                <a href="checkout.php"><button class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i> Buy Now</button></a>
               
            </div>
        </div>
        <div class="row px-xl-5">
            <div class="col">
                <div class="nav nav-tabs justify-content-center border-secondary mb-4">
                    
                    <a class="nav-item nav-link" data-toggle="tab" href="#tab-pane-2">Information</a>
                    
                </div>
               
                    <div class="tab-pane fade" id="tab-pane-2">
                        <h4 class="mb-3">Additional Information</h4>
                        <p>Fashion is a broad term: It can refer to the creation of clothing, accessories, and cosmetics, as well as the styles and trends that people use to put these items together. 
Fashion can be a form of self-expression: People use clothing to communicate their personalities, values, and interests. 
Fashion can be empowering: People who feel confident in their clothing are more likely to project a positive self-image. 
Fashion is influenced by culture: The amount and type of clothing people wear is influenced by their age, geography, culture, hobbies, and other factors. 
Fashion designers create clothing and accessories: They can specialize in clothing, accessories, or jewelry design. 
When writing product descriptions for clothing, consider the target customer: Think about how the customer thinks while shopping and what they're looking for. 
When writing product descriptions for clothing, include social proof: Tell customers that other people have already bought the product. </p>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item px-0">
                                    Party wear-red prom dress
                                    </li>
                                    <li class="list-group-item px-0">
                                    Traditional outfits.
                                    </li>
                                    <li class="list-group-item px-0">
                                    Looking for brand new look
                                    </li>
                                    <li class="list-group-item px-0">
                                    Top 2 brands that are highly used.
                                    </li>
                                  </ul> 
                            </div>
                            <div class="col-md-6">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item px-0">
                                    Simple outfits for home.
                                    </li>
                                    <li class="list-group-item px-0">
                                    formal wears and casual wears.
                                    </li>
                                   
                                  </ul> 
                            </div>
                        </div>
                    </div>
                                             
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Detail End -->


    


    <!-- Footer Start -->
    <?php
            include('footer.php');
        ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>