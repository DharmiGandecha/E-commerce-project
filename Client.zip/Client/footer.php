<head>
    <meta charset="utf-8">
    <title>contact page</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style1.css" rel="stylesheet">
</head>


<!-- Footer Start -->
<div class="container-fluid bg-secondary text-dark mt-5 pt-5" align="center">
    <div class="row px-xl-5 pt-5" >
        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5" style="margin-left: 460px;">
            <!--<a href="" class="text-decoration-none">
                <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">E</span>Shopper</h1>
            </a>-->
            
                <a href="" class="text-decoration-none">
                <h1>Closet Secrets</h1>
                <!--<h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">B</span>irthday</h1>-->
                </a>
            
            <!--<p>Dolore erat dolor sit lorem vero amet. Sed sit lorem magna, ipsum no sit erat lorem et magna ipsum dolore amet erat.</p>-->
           <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>Closet@gmail.com</p>
            <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>florida,near Calvin Klein Store,3rd Street,4th building..</p>
            <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>90540055278</p>
       
        </div>
        
            </div>
        </div>
    </div>
    
</div>
<!-- Footer End -->